from qgis.core import (QgsProcessing, QgsProcessingAlgorithm, QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer, QgsProcessingParameterRasterDestination, QgsRasterLayer)
import processing

class Plugin_TWI_SPIAlgorithm(QgsProcessingAlgorithm):

##ModeloSPI_TWI(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        # Definindo os parâmetros de entrada e saída
        self.addParameter(QgsProcessingParameterRasterLayer('dem', 'DEM', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterDestination('spi', 'SPI', createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterDestination('twi', 'TWI', createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(8, model_feedback)
        results = {}
        outputs = {}
        
        parameters['spi'].destinationName = 'Índice SPI'
        parameters['twi'].destinationName = 'Índice TWI'
        
        # Step 1: Reprojetar DEM para CRS do projeto
        feedback.pushInfo('Reprojetando DEM para o sistema de coordenadas do projeto...')
        alg_params = {
            'INPUT': parameters['dem'],
            'TARGET_CRS': 'ProjectCrs',
            'RESAMPLING': 0,  # Vizinhança Mais Próxima
            'NODATA': -9999,
            'TARGET_RESOLUTION': None,
            'OPTIONS': '',
            'DATA_TYPE': 0,
            'OUTPUT': 'ReprojectedDEM.tif'
        }
        outputs['ReprojectedDEM'] = processing.run('gdal:warpreproject', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Step 2: Preencher valores NoData no DEM
        feedback.pushInfo('Preenchendo valores NoData no DEM...')
        alg_params = {
            'INPUT': outputs['ReprojectedDEM']['OUTPUT'],
            'BAND': 1,
            'DISTANCE': 10,
            'ITERATIONS': 0,
            'NO_MASK': False,
            'OUTPUT': 'FilledDEM.tif'
        }
        outputs['FilledDEM'] = processing.run('gdal:fillnodata', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Step 3: Calcular Declividade do DEM
        feedback.pushInfo('Calculando a declividade a partir do DEM...')
        alg_params = {
            'INPUT': outputs['FilledDEM']['OUTPUT'],
            'Z_FACTOR': 1.0,
            'OUTPUT': 'SlopeDEM.tif'
        }
        outputs['Slope'] = processing.run('native:slope', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Step 4: Converter Declividade para Radianos
        feedback.pushInfo('Convertendo declividade para radianos...')
        alg_params = {
            'INPUT_A': outputs['Slope']['OUTPUT'],
            'BAND_A': 1,
            'FORMULA': 'A * 3.14159265359 / 180',
            'OUTPUT': 'SlopeRadians.tif'
        }
        outputs['SlopeRadians'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Step 5: Calcular Acumulação de Fluxo usando GRASS GIS
        feedback.pushInfo('Calculando acumulação de fluxo usando GRASS GIS...')
        alg_params = {
            'elevation': outputs['FilledDEM']['OUTPUT'],
            'accumulation': 'FlowAccumulation.tif',
            'memory': 300,
            'convergence': 5,
            'flags': '',
            'GRASS_REGION_PARAMETER': None,
            'GRASS_REGION_CELLSIZE_PARAMETER': 0,
            'NODATA': -9999
        }
        outputs['FlowAccumulation'] = processing.run('grass7:r.watershed', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Step 6: Obter o tamanho da célula (Cell Size)
        feedback.pushInfo('Obtendo o tamanho da célula...')
        dem_raster = QgsRasterLayer(outputs['FilledDEM']['OUTPUT'], 'Filled DEM')
        if not dem_raster.isValid():
            feedback.reportError('Falha ao carregar a camada raster do DEM.')
            return {}
        cell_size_x = dem_raster.rasterUnitsPerPixelX()
        cell_size_y = dem_raster.rasterUnitsPerPixelY()
        cell_size = (cell_size_x + cell_size_y) / 2  # Assumindo pixels quadrados
        feedback.pushInfo(f'Tamanho da célula: {cell_size}')

        # Step 7: Calcular SPI (Correção na Fórmula)
        feedback.pushInfo('Calculando SPI...')
        alg_params = {
            'INPUT_A': outputs['FlowAccumulation']['accumulation'],
            'BAND_A': 1,
            'INPUT_B': outputs['SlopeRadians']['OUTPUT'],
            'BAND_B': 1,
            'FORMULA': '((A >= 0) * (A * {cell_size}) * tan(B))'.format(cell_size=cell_size),
            'NODATA_A': -9999,
            'NODATA_B': -9999,
            'OUTPUT': parameters['spi']
        }
        outputs['SPI'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['spi'] = outputs['SPI']['OUTPUT']

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Step 8: Calcular TWI
        feedback.pushInfo('Calculando TWI...')
        alg_params = {
            'INPUT_A': outputs['FlowAccumulation']['accumulation'],
            'BAND_A': 1,
            'INPUT_B': outputs['SlopeRadians']['OUTPUT'],
            'BAND_B': 1,
            'FORMULA': 'log((A * {cell_size}) / (tan(B) + 0.001))'.format(cell_size=cell_size),
            'NODATA_A': -9999,
            'NODATA_B': -9999,
            'OUTPUT': parameters['twi']
        }
        outputs['TWI'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['twi'] = outputs['TWI']['OUTPUT']

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        return results
    def shortHelpString(self):
            return """
    <html>
    <body>
    <h3>Cálculo de Índices Topográficos: SPI e TWI</h3>
    <p>Este algoritmo calcula dois índices derivados do relevo a partir de um Modelo Digital de Elevação (MDE), fundamentais para diagnósticos ambientais e suporte a projetos de Recuperação de Áreas Degradadas (PRAD):</p>

    <h4>1. Stream Power Index (SPI)</h4>
    <p>O <strong>SPI</strong> (Índice de Potência do Fluxo) expressa a energia potencial do escoamento superficial, associada à força erosiva da água sobre o solo.</p>
    <ul>
      <li><strong>Fórmula:</strong> SPI = A<sub>s</sub> × tan(β)</li>
      <li><strong>Faixa de valores esperados:</strong> Normalmente varia de 0 até valores elevados (&gt;1000) em áreas de grande acumulação de fluxo.</li>
      <li><strong>Interpretação:</strong>
        <ul>
          <li>Valores baixos (&lt;50): Encostas estáveis, baixo potencial erosivo.</li>
          <li>Valores médios (50–200): Escoamento concentrado moderado.</li>
          <li>Valores altos (&gt;200): Elevada energia do fluxo, risco de erosão e formação de ravinas.</li>
        </ul>
      </li>
    </ul>

    <h4>2. Topographic Wetness Index (TWI)</h4>
    <p>O <strong>TWI</strong> (Índice de Umidade Topográfica) representa a tendência de saturação hídrica e infiltração, calculado a partir da área de contribuição e da declividade.</p>
    <ul>
      <li><strong>Fórmula:</strong> TWI = ln(A<sub>s</sub> / tan(β))</li>
      <li><strong>Faixa de valores esperados:</strong> Geralmente entre 4 e 20, dependendo da escala e do relevo.</li>
      <li><strong>Interpretação:</strong>
        <ul>
          <li>Valores baixos (&lt;7): Encostas drenadas, maior risco de erosão.</li>
          <li>Valores médios (8–12): Áreas de transição, potencial para recarga hídrica.</li>
          <li>Valores altos (&gt;12): Baixadas úmidas e zonas de infiltração prioritária.</li>
        </ul>
      </li>
    </ul>

    <h4>Aplicação Ambiental</h4>
    <p>Os índices SPI e TWI permitem identificar zonas de <strong>fragilidade ambiental</strong>, <strong>risco de erosão</strong> e <strong>áreas prioritárias para recomposição vegetal</strong>. 
    O cruzamento entre SPI e TWI auxilia no planejamento de práticas conservacionistas, como reflorestamento, terraceamento e controle de drenagem.</p>

    <h4>Referências</h4>
    <p>Moore & Nieber (1989); Moore et al. (1991); Qin et al. (2009); Riihimäki et al. (2021); Dambroz et al. (2022); Samuel-Rosa et al. (2013).</p>

    </body>
    </html>
    """

    def helpUrl(self):
        return 'https://drive.google.com/file/d/1Ae2EFqDTQgXm9JcdftcuoLsmcsG_VRjd/view?usp=sharing'   

    def name(self):
        return 'modelo_spi_twi'

    def displayName(self):
        return 'Índices Topográficos SPI e TWI'

    def group(self):
        return 'Geoprocessamento'

    def groupId(self):
        return 'geoprocessamento'

    def createInstance(self):
        return Plugin_TWI_SPIAlgorithm()
